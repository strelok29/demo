# CV
my personal CV based on Django framework

set Alowed host on "settings.py" in "djangotest" file to your domain

## project not complete
